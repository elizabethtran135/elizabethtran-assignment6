var members = [
  'Dave Grohl',
  'Nate Mendel',
  'Pat Smear',
  'Taylor Hawkins',
  'Rami Jaffee',
  'Chris Shiflett'
];

//object
var tour = {
  Chicago: "July 29th & 30th, 2018",
  Seattle: "September 1st, 2018",
  Edmonton:  "September 4th, 2018"
};

//While loops
var i =0

while (x < 5) {
  console.log('Times running through the loop x: ' + x);
  x++;
}
